export { default as Footer } from '../..\\components\\Footer.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as PopupServices } from '../..\\components\\Popup_services.vue'
export { default as Subscribe } from '../..\\components\\Subscribe.vue'
export { default as IndexSection2 } from '../..\\components\\index\\Section2.vue'
export { default as IndexSection3 } from '../..\\components\\index\\Section3.vue'
export { default as IndexSection4 } from '../..\\components\\index\\Section4.vue'
export { default as IndexSection5 } from '../..\\components\\index\\Section5.vue'
export { default as IndexSection6 } from '../..\\components\\index\\Section6.vue'
export { default as IndexSection7 } from '../..\\components\\index\\Section7.vue'

export const LazyFooter = import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const LazyHeader = import('../..\\components\\Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c))
export const LazyPopupServices = import('../..\\components\\Popup_services.vue' /* webpackChunkName: "components/popup-services" */).then(c => wrapFunctional(c.default || c))
export const LazySubscribe = import('../..\\components\\Subscribe.vue' /* webpackChunkName: "components/subscribe" */).then(c => wrapFunctional(c.default || c))
export const LazyIndexSection2 = import('../..\\components\\index\\Section2.vue' /* webpackChunkName: "components/index-section2" */).then(c => wrapFunctional(c.default || c))
export const LazyIndexSection3 = import('../..\\components\\index\\Section3.vue' /* webpackChunkName: "components/index-section3" */).then(c => wrapFunctional(c.default || c))
export const LazyIndexSection4 = import('../..\\components\\index\\Section4.vue' /* webpackChunkName: "components/index-section4" */).then(c => wrapFunctional(c.default || c))
export const LazyIndexSection5 = import('../..\\components\\index\\Section5.vue' /* webpackChunkName: "components/index-section5" */).then(c => wrapFunctional(c.default || c))
export const LazyIndexSection6 = import('../..\\components\\index\\Section6.vue' /* webpackChunkName: "components/index-section6" */).then(c => wrapFunctional(c.default || c))
export const LazyIndexSection7 = import('../..\\components\\index\\Section7.vue' /* webpackChunkName: "components/index-section7" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
export function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
