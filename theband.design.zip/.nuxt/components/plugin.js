import Vue from 'vue'
import { wrapFunctional } from './index'

const components = {
  Footer: () => import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c)),
  Header: () => import('../..\\components\\Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c)),
  PopupProjects: () => import('../..\\components\\Popup_projects.vue' /* webpackChunkName: "components/popup-projects" */).then(c => wrapFunctional(c.default || c)),
  PopupServices: () => import('../..\\components\\Popup_services.vue' /* webpackChunkName: "components/popup-services" */).then(c => wrapFunctional(c.default || c)),
  Subscribe: () => import('../..\\components\\Subscribe.vue' /* webpackChunkName: "components/subscribe" */).then(c => wrapFunctional(c.default || c)),
  IndexSection2: () => import('../..\\components\\index\\Section2.vue' /* webpackChunkName: "components/index-section2" */).then(c => wrapFunctional(c.default || c)),
  IndexSection3: () => import('../..\\components\\index\\Section3.vue' /* webpackChunkName: "components/index-section3" */).then(c => wrapFunctional(c.default || c)),
  IndexSection4: () => import('../..\\components\\index\\Section4.vue' /* webpackChunkName: "components/index-section4" */).then(c => wrapFunctional(c.default || c)),
  IndexSection5: () => import('../..\\components\\index\\Section5.vue' /* webpackChunkName: "components/index-section5" */).then(c => wrapFunctional(c.default || c)),
  IndexSection6: () => import('../..\\components\\index\\Section6.vue' /* webpackChunkName: "components/index-section6" */).then(c => wrapFunctional(c.default || c)),
  IndexSection7: () => import('../..\\components\\index\\Section7.vue' /* webpackChunkName: "components/index-section7" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
