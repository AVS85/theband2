# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Footer>` | `<footer>` (components/Footer.vue)
- `<Header>` | `<header>` (components/Header.vue)
- `<PopupProjects>` | `<popup-projects>` (components/Popup_projects.vue)
- `<PopupServices>` | `<popup-services>` (components/Popup_services.vue)
- `<Subscribe>` | `<subscribe>` (components/Subscribe.vue)
- `<IndexSection2>` | `<index-section2>` (components/index/Section2.vue)
- `<IndexSection3>` | `<index-section3>` (components/index/Section3.vue)
- `<IndexSection4>` | `<index-section4>` (components/index/Section4.vue)
- `<IndexSection5>` | `<index-section5>` (components/index/Section5.vue)
- `<IndexSection6>` | `<index-section6>` (components/index/Section6.vue)
- `<IndexSection7>` | `<index-section7>` (components/index/Section7.vue)
