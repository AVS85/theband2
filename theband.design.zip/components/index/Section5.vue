<template>
<section class="container index_section5">
	<div class="row justify-content-between">
		<div class="col-md-6">
			<h2 class="section_title">Используем продуктовый подход для создания сильных презентаций и достижения результата</h2>
			<p class="section_subtitle text2">Работаем по фреймворку: начинаем с целей, анализа контента, поиска сути, создаём концепцию, упаковываем в дизайн</p>
		</div>
		<div class="col-md-4">
			<img src="/section5.svg" alt="SlideBand - продуктовый подход">
		</div>
	</div>
</section>
</template>

<style lang="sass">
.index_section5
	img
		width: 100%
</style>