<template>
  <div>
    <Header/>
    <Nuxt />
    <Footer/>
  </div>
</template>

<style lang="sass">

</style>
